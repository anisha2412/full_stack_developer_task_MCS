var base_url = $('#baseurl').val();

$(document).on('click',"#reg_btn",function()
{ 
	$(".form_control").val('');		
});

$(document).on('click',"#submitBtn",function()
{ 
	var name=$("#name").val().trim();
	var email = $('#email').val().trim();
	var mobile_number=$("#mobile_number").val().trim();
	var address = $('#address').val().trim();
	var record_value =$("#record_value").val().trim();

	if(name=="" )
	{	
		messagefunctioning("Please enter name.","error")
	}
	else if(email=="" )
	{
		messagefunctioning("Please email address.","error")
	}
	else if(mobile_number=="" )
	{
		messagefunctioning("Please enter mobile number.","error")
	}
	else
	{		
		$.ajax({
        url: base_url+"Home/register",
        type: 'POST',
		data:{ name : name,
			email : email,
			mobile_number:mobile_number,
			address:address ,
			record_value : record_value},
		headers:"Content-Type':'text/html'; charset:utf-8",    
       	async:false, 
        success: function (result) {
			var messageresult=result.message;	
			if(result.result=="inserted")			
			{								
				$(".form_control").val('');						 
				messagefunctioning(messageresult,"success");
				$('#exampleModal').modal('hide'); 
				$('#exampleModal').on('hidden.bs.modal', function () {
					setTimeout(function() {
						location.reload(); 
					}, 2010); 
				});					
				return;						
			}
			else
			{
				messagefunctioning(messageresult,"error");	
			}			
		},
       error: function(XMLHttpRequest, textStatus, errorThrown) 
	   {   
	      messagefunctioning("Some error occured.","error")
        }
    });			
}
});



function vote(option) {		
  $.ajax({
      url: base_url +"home/poll",
      type: 'POST',
      data: {option: option},
success: function() {
          getResults();
      }
  });
}


function getResults() {
  $.ajax({
    url: base_url +"home/get_results",
    type: 'GET',
    dataType: 'json', 
    success: function(response) {

    $('#poll').hide();
    $('#poll_result').show();

    $('#yes').css('width', response.yes_percentage + '%').text("Yes : " + response.yes_percentage + '%');
    $('#no').css('width', response.no_percentage + '%').text("No : " + response.no_percentage + '%');

    }
  });
}































resetToastPosition = function() {
    $('.jq-toast-wrap').removeClass('bottom-left bottom-right top-left top-right mid-center'); // to remove previous position class
    $(".jq-toast-wrap").css({
      "top": "",
      "left": "",
      "bottom": "",
      "right": ""
    });  
}


function messagefunctioning(msg,type)
{   

showSuccessToast = function() {
    'use strict';
    resetToastPosition();
    $.toast({
      heading: 'Success',
      text: msg,
      showHideTransition: 'slide',
      icon: 'success',
      loaderBg: '#f96868',
      position: 'top-right'
    })
  };
  showInfoToast = function() {
    'use strict';
    resetToastPosition();
    $.toast({
      heading: 'Info',
      text: msg,
      showHideTransition: 'slide',
      icon: 'info',
      loaderBg: '#46c35f',
      position: 'top-right'
    })
  };
  showWarningToast = function() {
    'use strict';
    resetToastPosition();
    $.toast({
      heading: 'Warning',
       text: msg,
      showHideTransition: 'slide',
      icon: 'warning',
      loaderBg: '#57c7d4',
      position: 'top-right'
    })
  };
  showDangerToast = function() {
    'use strict';
    resetToastPosition();
    $.toast({
      heading: 'Danger',
       text: msg,
      showHideTransition: 'slide',
      icon: 'error',
      loaderBg: '#f2a654',
      position: 'top-right'
    })
  };
  if(type=="success")
  showSuccessToast();
else if(type=="error")
  showDangerToast();
else if(type=="info")
  showInfoToast();
else if(type=="warning")
  showWarningToast();
	
}