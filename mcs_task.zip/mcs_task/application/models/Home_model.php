<?php	defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }


	public function member_registration($data) {
	
		$sql = 'SELECT * FROM member WHERE name = ? and email = ? and mobile_number = ? and address = ?
		and id != ?';
		$binds = array($data['name'],$data['email'],$data['mobile_number'],$data['address'],$data['id']);
		$query = $this->db->query($sql, $binds);
		
		if ($query->num_rows() > 0) {
			return "exist";
		} 
		else 
		{
			if($data['id']=='0')
			{
				$sql = 'INSERT INTO member (name, email, mobile_number, address, created_at) VALUES (?, ?, ?, ?, ?)';
				$binds = array($data['name'], $data['email'], $data['mobile_number'], $data['address'], $data['created_at']);
				$query = $this->db->query($sql, $binds);
				return "inserted";
			}						    
		}		
	}
	
	
	public function save_poll($option) {
        $data = array(
            'option_selected' => $option
        );
        $this->db->insert('poll', $data);
    }

    public function get_results() {
        $total_votes = $this->db->count_all('poll');
        $yes_votes = $this->db->where('option_selected', 1)->count_all_results('poll');
        $no_votes = $this->db->where('option_selected', 0)->count_all_results('poll');
        $yes_percentage = ($total_votes > 0) ? round(($yes_votes / $total_votes) * 100, 2) : 0;
        $no_percentage = ($total_votes > 0) ? round(($no_votes / $total_votes) * 100, 2) : 0;
        return array(
            'yes_percentage' => $yes_percentage,
            'no_percentage' => $no_percentage
        );
    }
	
	
	
	
	

}
?>