<!DOCTYPE HTML>
<html lang="zxx">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>MCS Task</title>
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css" media="all" />
		<!-- Slick nav CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/slicknav.min.css" media="all" />
		<!-- Iconfont CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/icofont.css" media="all" />
		<!-- Slick CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/slick.css">

		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<!-- Owl carousel CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/owl.carousel.css">
		<!-- Popup CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css">
		<!-- Switcher CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/switcher-style.css">
		<!-- Animate CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/animate.min.css">
		<!-- Main style CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
		<!-- Responsive CSS -->
		<link rel="stylesheet" type="text/css" href="assets/css/responsive.css" media="all" />
		<!-- Favicon Icon -->
		<link rel="icon" type="image/png" href="assets/img/favcion.png" />
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->


		<link rel="stylesheet" href="assets/js/jquery.toast.css">

		<link rel="stylesheet" type="text/css" href="assets/css/why_choose_us.css" media="all" />

		<!-- <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.2/dist/css/bootstrap.min.css"> -->
<link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.3/components/testimonials/testimonial-3/assets/css/testimonial-3.css">


	</head>

<style>
    button#submitBtn {
        padding: 10px 20px;
        border: none;
        background-color: #f0f0f0; 
        color: #000; 
        cursor: pointer;
        transition: background-color 0.3s ease;
    }
    button#submitBtn:hover {
        background-color: #007bff; 
        color: #fff; 
    }

	.notification {
		position: relative;
		display: inline-block;
		padding: 5px 10px;
		background-color: white;
		color: black;
		border-radius: 50px; 
	}

	.notification i {
		margin-right: 5px; 
	}

	@media only screen and (min-width: 768px) {
		.mobile_footer{
			display: none;
		}
	}

	.home-testimonial{background-color: #231834;height: 380px}.home-testimonial-bottom{background-color: #f8f8f8;transition: background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;margin-top: 20px;margin-bottom: 0px;position: relative;height: 130px;top: 190px}.home-testimonial h3{color: var(--orange);font-size: 14px;font-weight: 500;text-transform: uppercase}.home-testimonial h2{color: white;font-size: 28px;font-weight: 700}.testimonial-inner{position: relative;top: -174px}.testimonial-pos{position: relative;top: 24px}.testimonial-inner .tour-desc{border-radius: 5px;padding: 40px}.color-grey-3{font-family: "Montserrat", Sans-serif;font-size: 14px;color: #6c83a2}.testimonial-inner img.tm-people{width: 60px;height: 60px;-webkit-border-radius: 50%;border-radius: 50%;-o-object-fit: cover;object-fit: cover;max-width: none}.link-name{font-family: "Montserrat", Sans-serif;font-size: 14px;color: #6c83a2}.link-position{font-family: "Montserrat", Sans-serif;font-size: 12px;color: #6c83a2}
</style>

<?php
	$sql = 'SELECT COUNT(*) AS member_count FROM member;';
	$query = $this->db->query($sql);
	$result = $query->result_array();
	$member_count = $result[0]['member_count'];
?>

	<body data-spy="scroll" data-target=".header" data-offset="50">
		<!-- Page loader -->
	    <div id="preloader"></div>
		<!-- header section start -->
		<header class="header">
			<div class="container">
				<div class="row flexbox-center">
					


					<div class="container">
    <div class="row">
	<div class="col-lg-2 col-md-2 col-2">
            <div class="logo" style="margin-left: -20px;"> 
                <a href="#home"><img src="assets/img/logo.png" alt="logo" style="margin-left: -20px;" /></a>
            </div>
        </div>



		<div class="col-lg-10 col-md-10 col-10">
            <div class="responsive-menu"></div>
			
			
            <div class="mainmenu">
				<ul id="primary-menu" class="menu-list">
					<li><a class="nav-link active" href="#home">Offerings</a></li>
					<li><a class="nav-link" href="#feature">Feature</a></li>
					<li><a class="nav-link" href="#testimonial">Client Testimonials</a></li>
					<li><a class="nav-link" href="#why_choose_us">Why choose us ?</a></li>
					<li><a class="nav-link" href="#rating">Rating & Recognitions</a></li>

					<li><a class="" data-toggle="modal" data-target="#exampleModal" id="reg_btn" data-whatever="@mdo" 
					href="#">Registration</a></li>

					<div class="notification">
						<i title="Total members" style="font-size: 18px;" class="icofont icofont-users-alt-3"></i>
						<span style="font-size: 18px;" title="Total members"><?php echo $member_count; ?></span>
					</div>

				</ul>
			</div>

			
			
        </div>
    </div>
</div>

				</div>
			</div>

		</header><!-- header section end -->
		
		<!-- hero area start -->
		<section class="hero-area" id="home">
			<div class="container">
				<div class="row">
					<div class="col-lg-7">
						<div class="hero-area-content">

<div id="poll">
    <h3>Do you like this training?</h3>
	<a href="#" onclick="vote(1)" class="appao-btn">Yes</a>
	<a href="#" onclick="vote(0)" class="appao-btn">No</a>
</div>

<br>

<div id="poll_result" style="display:none">
<h3>Poll Results</h3><br>
<div class="progress">
  <div class="progress-bar" id="yes" role="progressbar"  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
</div>
<br>
<div class="progress">
  <div class="progress-bar" id="no" role="progressbar"  aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
</div>

<br>
</div>

							<h1>It’s all about Promoting your Business</h1>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo </p>
							<a href="#" class="appao-btn">Google Play</a>
							<a href="#" class="appao-btn">App Store</a>
						</div>
					</div>
					<div class="col-lg-5">
					    <div class="hand-mockup text-lg-left text-center">
							<img src="assets/img/hand-mockup.png" alt="Hand Mockup" />
						</div>
					</div>
				</div>
			</div>
		</section><!-- hero area end -->
		
		
		<!-- about section start -->
		
		<!--<section class="about-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>About Prantokon<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-4">
					    <div class="single-about-box">
							<i class="icofont icofont-ruler-pencil"></i>
							<h4>Responsive Design</h4>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text</p>
						</div>
					</div>
					<div class="col-lg-4">
					    <div class="single-about-box active">
							<i class="icofont icofont-computer"></i>
							<h4>Fast Performance</h4>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text</p>
						</div>
					</div>
					<div class="col-lg-4">
					    <div class="single-about-box">
							<i class="icofont icofont-headphone-alt"></i>
							<h4>Cross Platfrom</h4>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text</p>
						</div>
					</div>
				</div>
			</div>
		</section>-->
		
		<!-- about section end -->
		
		
		<!-- feature section start -->
		<section class="feature-area ptb-90" id="feature">
			<div class="container">
				<div class="row flexbox-center">
					<div class="col-lg-4">
						<div class="single-feature-box text-lg-right text-center">
							<ul>
								<li>
									<div class="feature-box-info">
										<h4>Unlimited Features</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-brush"></i>
									</div>
								</li>
								<li>
									<div class="feature-box-info">
										<h4>Responsive Design</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-computer"></i>
									</div>
								</li>
								<li>
									<div class="feature-box-info">
										<h4>Well Documented</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-law-document"></i>
									</div>
								</li>
								<li>
									<div class="feature-box-info">
										<h4>Full Free Chat</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
									<div class="feature-box-icon">
										<i class="icofont icofont-heart-beat"></i>
									</div>
								</li>
							</ul>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="single-feature-box text-center">
							<img src="assets/img/feature.png" alt="feature">
						</div>
					</div>
					<div class="col-lg-4">
						<div class="single-feature-box text-lg-left text-center">
							<ul>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-eye"></i>
									</div>
									<div class="feature-box-info">
										<h4>Retina ready</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
								</li>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-sun-alt"></i>
									</div>
									<div class="feature-box-info">
										<h4>High Resolution</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
								</li>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-code-alt"></i>
									</div>
									<div class="feature-box-info">
										<h4>Clean Codes</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
								</li>
								<li>
									<div class="feature-box-icon">
										<i class="icofont icofont-headphone-alt"></i>
									</div>
									<div class="feature-box-info">
										<h4>Helping Supports</h4>
										<p>Lorem ipsum dolor amet consectetur adipisicing eiusmod </p>
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section><!-- feature section end -->
		
		
		
		<!-- showcase section start -->
		
		
		<!--  <section class="showcase-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Showcase<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt</p>
						</div>
					</div>
				</div>
				<div class="row flexbox-center">
					<div class="col-lg-6">
						<div class="single-showcase-box">
							<h4>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim nostrud exercitation ullamco laboris nisi ut aliquip </p>
							<a href="#" class="appao-btn appao-btn2">Read More</a>
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single-showcase-box">
							<img src="assets/img/showcase.png" alt="showcase">
						</div>
					</div>
				</div>
				<div class="row flexbox-center">
					<div class="col-lg-6">
						<div class="single-showcase-box">
							<img src="assets/img/showcase2.png" alt="showcase">
						</div>
					</div>
					<div class="col-lg-6">
						<div class="single-showcase-box">
							<h4>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim nostrud exercitation ullamco laboris nisi ut aliquip </p>
							<a href="#" class="appao-btn appao-btn2">Read More</a>
						</div>
					</div>
				</div>
			</div>
		</section>-->
		<!-- showcase section end -->
		
		
		
	

		<!-- testimonial section start -->
		<section class="testimonial-area ptb-90" id="testimonial">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Client Testimonials<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt </p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-8 offset-lg-2">
						<div class="testimonial-wrap">
							<div class="single-testimonial-box">
								<div class="author-img">
									<img src="assets/img/author/author1.jpg" alt="author" />
								</div>
								<h5>Mary Balogh</h5>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in </p>
								<div class="author-rating">
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
								</div>
							</div>
							<div class="single-testimonial-box">
								<div class="author-img">
									<img src="assets/img/author/author2.jpg" alt="author" />
								</div>
								<h5>Mary Balogh</h5>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in </p>
								<div class="author-rating">
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
								</div>
							</div>
							<div class="single-testimonial-box">
								<div class="author-img">
									<img src="assets/img/author/author2.jpg" alt="author" />
								</div>
								<h5>Mary Balogh</h5>
								<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi  aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in </p>
								<div class="author-rating">
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
									<i class="icofont icofont-star"></i>
								</div>
							</div>
						</div>
						<div class="testimonial-thumb">
							<div class="thumb-prev">
								<div class="author-img">
									<img src="assets/img/author/author2.jpg" alt="author" />
								</div>
							</div>
							<div class="thumb-next">
								<div class="author-img">
									<img src="assets/img/author/author2.jpg" alt="author" />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section><!-- testimonial section end -->
		
		
		<!-- counter section start -->
		<section class="counter-area ptb-90">
		
			<div class="container">
				<div class="row">
				
					<!-- <div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-heart-alt"></i>
							<h1><span class="counter">9798</span></h1>
							<p>Happy Client</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-protect"></i>
							<h1><span class="counter">9798</span></h1>
							<p>Completed Project</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-download-alt"></i>
							<h1><span class="counter">979</span>K</h1>
							<p>Apps Download</p>
						</div>
					</div>
					<div class="col-md-3 col-sm-6">
					    <div class="single-counter-box">
							<i class="icofont icofont-trophy"></i>
							<h1><span class="counter">250</span></h1>
							<p>Our Award</p>
						</div>
					</div>-->
					
					
				</div>
			</div>
		</section><!-- counter section end -->
		
		
		
		<!-- team section start -->
		
		<!--  <section class="team-area ptb-90" id="team">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Meet Our Team<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt </p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/team1.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="#"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>John Deo</h4></a>
								<p>Web Developer</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/team2.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="#"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Sharon Garcia</h4></a>
								<p>UX Designer</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/team3.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="#"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Elijah Henderson</h4></a>
								<p>UX Designer</p>
							</div>
						</div>
					</div>
					<div class="col-lg-3 col-sm-6">
					    <div class="single-team-member">
							<div class="team-member-img">
								<img src="assets/img/team/team4.jpg" alt="team">
								<div class="team-member-icon">
									<div class="display-table">
										<div class="display-tablecell">
											<a href="#"><i class="icofont icofont-social-facebook"></i></a>
											<a href="#"><i class="icofont icofont-social-twitter"></i></a>
											<a href="#"><i class="icofont icofont-brand-linkedin"></i></a>
											<a href="#"><i class="icofont icofont-social-pinterest"></i></a>
										</div>
									</div>
								</div>
							</div>
							<div class="team-member-info">
								<a href="#"><h4>Sharon Garcia</h4></a>
								<p>UX Designer</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>-->
		
		
		
		
		<section class="team-area ptb-90" id="why_choose_us">
	 
	 <div class="feat bg-gray pt-5 pb-5">
    <div class="container">
      <div class="row">
        <div class="section-head col-sm-12">
          <h4><span>Why Choose</span> Us?</h4>
          <p>When you choose us, you'll feel the benefit of 10 years' experience of Web Development. Because we know the digital world and we know that how to handle it. With working knowledge of online, SEO and social media.</p>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item"> <span class="icon feature_box_col_one"><i class="fa fa-globe"></i></span>
            <h6>Modern Design</h6>
            <p>We use latest technology for the latest world because we know the demand of peoples.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item"> <span class="icon feature_box_col_two"><i class="fa fa-anchor"></i></span>
            <h6>Creative Design</h6>
            <p>We are always creative and and always lisen our costomers and we mix these two things and make beast design.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item"> <span class="icon feature_box_col_three"><i class="fa fa-hourglass-half"></i></span>
            <h6>24 x 7 User Support</h6>
            <p>If our customer has any problem and any query we are always happy to help then.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item"> <span class="icon feature_box_col_four"><i class="fa fa-database"></i></span>
            <h6>Business Growth</h6>
            <p>Everyone wants to live on top of the mountain, but all the happiness and growth occurs while you're climbing it</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item"> <span class="icon feature_box_col_five"><i class="fa fa-upload"></i></span>
            <h6>Market Strategy</h6>
            <p>Holding back technology to preserve broken business models is like allowing blacksmiths to veto the internal combustion engine in order to protect their horseshoes.</p>
          </div>
        </div>
        <div class="col-lg-4 col-sm-6">
          <div class="item"> <span class="icon feature_box_col_six"><i class="fa fa-camera"></i></span>
            <h6>Affordable cost</h6>
            <p>Love is a special word, and I use it only when I mean it. You say the word too much and it becomes cheap.</p>
          </div>
        </div>
      </div>
    </div>
  </div>

			
			
			
			
		</section>
		
		
		
		
		
		<!-- team section end -->
		
		
		
		
			
		<!-- download section start -->
		<!-- <section class="download-area ptb-90">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					    <div class="sec-title">
							<h2>Download Available<span class="sec-title-border"><span></span><span></span><span></span></span></h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt </p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12">
						<ul>
							<li>
								<a href="#" class="download-btn flexbox-center">
									<div class="download-btn-icon">
										<i class="icofont icofont-brand-android-robot"></i>
									</div>
									<div class="download-btn-text">
										<p>Available on</p>
										<h4>Android Store</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#" class="download-btn flexbox-center">
									<div class="download-btn-icon">
										<i class="icofont icofont-brand-apple"></i>
									</div>
									<div class="download-btn-text">
										<p>Available on</p>
										<h4>Apple Store</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#" class="download-btn flexbox-center">
									<div class="download-btn-icon">
										<i class="icofont icofont-brand-windows"></i>
									</div>
									<div class="download-btn-text">
										<p>Available on</p>
										<h4>Windows Store</h4>
									</div>
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</section>-->
		
		<!-- download section end -->
		
		
		
		
		
		<!-- download section start -->
		<section class="download-area ptb-90" id="rating">
		
		
			<!-- Testimonial 3 - Bootstrap Brain Component -->
<section class="bg-light py-5 py-xl-8">
  <div class="container">
    <div class="row justify-content-md-center">
      <div class="col-12 col-md-10 col-lg-8 col-xl-7 col-xxl-6">
        <h3 class="fs-6 text-secondary mb-2 text-uppercase text-center">Happy Customers</h3>
        
        <hr class="w-50 mx-auto mb-5 mb-xl-9 border-dark-subtle">
      </div>
    </div>
  </div>

  <div class="container overflow-hidden">
    <div class="row gy-4 gy-md-0 gx-xxl-5">
      <div class="col-12 col-md-4">
        <div class="card border-0 border-bottom border-primary shadow-sm">
          <div class="card-body p-4 p-xxl-5">
            <figure>
              <img class="img-fluid rounded rounded-circle mb-4 border border-5" loading="lazy" src="./assets/img/face9.jpg" alt="Luna John">
              <figcaption>
                <div class="bsb-ratings text-warning mb-3" data-bsb-star="5" data-bsb-star-off="0"></div>
                <blockquote class="bsb-blockquote-icon mb-4 text-dark">We were so impressed with the work they did for us. They were able to take our vision and turn it into a reality, and they did it all on time and within budget. We would highly recommend them to anyone looking for a reliable partner.</blockquote>
                <h4 class="mb-2">Luna John</h4>
                <h5 class="fs-6 text-secondary mb-0">UX Designer</h5>
              </figcaption>
            </figure>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-4">
        <div class="card border-0 border-bottom border-primary shadow-sm">
          <div class="card-body p-4 p-xxl-5">
            <figure>
              <img class="img-fluid rounded rounded-circle mb-4 border border-5" loading="lazy" src="./assets/img/face10.jpg" alt="Mark Smith">
              <figcaption>
                <div class="bsb-ratings text-warning mb-3" data-bsb-star="4" data-bsb-star-off="1"></div>
                <blockquote class="bsb-blockquote-icon mb-4 text-dark">We were looking for a company that could help us develop a new website that was both visually appealing and user-friendly. We are so happy with the results, and we would highly recommend them to anyone looking for a new website.</blockquote>
                <h4 class="mb-2">Mark Smith</h4>
                <h5 class="fs-6 text-secondary mb-0">Marketing Specialist</h5>
              </figcaption>
            </figure>
          </div>
        </div>
      </div>
      <div class="col-12 col-md-4">
        <div class="card border-0 border-bottom border-primary shadow-sm">
          <div class="card-body p-4 p-xxl-5">
            <figure>
              <img class="img-fluid rounded rounded-circle mb-4 border border-5" loading="lazy" src="./assets/img/face11.jpg" alt="Luke Reeves">
              <figcaption>
                <div class="bsb-ratings text-warning mb-3" data-bsb-star="5" data-bsb-star-off="0"></div>
                <blockquote class="bsb-blockquote-icon mb-4 text-dark">We were looking for a company that could help us with our branding. We needed a website and marketing materials. They were able to create a brand identity that we loved. They worked with us to develop a logo that represented our company.</blockquote>
                <h4 class="mb-2">Luke Reeves</h4>
                <h5 class="fs-6 text-secondary mb-0">Sales Manager</h5>
              </figcaption>
            </figure>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
			
		</section>
		
		
		<!-- download section end -->
		
		
		
		
		
	
		
		
		
		<!-- google map area start -->
		<div class=""></div>
		<!-- google map area end -->
		<!-- footer section start -->


		<footer class="footer" id="contact">
			<div class="container">
				<div class="row">
                    <div class="col-lg-6">
						<div class="contact-form">
							<h4>Get in Touch</h4>
							<p class="form-message"></p>
							<form id="contact-form" action="#" method="POST">
				                <input type="text" name="name" placeholder="Enter Your Name">
				                <input type="email" name="email" placeholder="Enter Your Email">
				                <input type="text" name="subject" placeholder="Your Subject">
				                <textarea placeholder="Messege" name="message"></textarea>
				                <button type="submit" name="submit">Send Message</button>
				            </form>
						</div>
                    </div>
                    <div class="col-lg-6">
						<div class="contact-address">
							<h4>Address</h4>
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
								 labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud</p>
							<ul>
								<li>
									<div class="contact-address-icon">
										<i class="icofont icofont-headphone-alt"></i>
									</div>
									<div class="contact-address-info">
										<a href="callto:#">+8801712435941</a>
										<a href="callto:#">+881934180093</a>
									</div>
								</li>
								<li>
									<div class="contact-address-icon">
										<i class="icofont icofont-envelope"></i>
									</div>
									<div class="contact-address-info">
										<a href="mailto:#">Jsoftbd87gmail.com</a>
									</div>
								</li>
								<li>
									<div class="contact-address-icon">
										<i class="icofont icofont-web"></i>
									</div>
									<div class="contact-address-info">
										<a href="www.jsoftbd.com">www.jsoftbd.com</a>
									</div>
								</li>
							</ul>
						</div>
                    </div>
				</div>
				<div class="row">
                    <div class="col-lg-12">
						<div class="subscribe-form">
							<form action="#">
								<input type="text" placeholder="Your email address here">
								<button type="submit">Subcribe</button>
							</form>
						</div>
                    </div>
				</div>
				<div class="row">
                    <div class="col-lg-12">
						<div class="copyright-area">
							<ul>
								<li><a href="#"><i class="icofont icofont-social-facebook"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-twitter"></i></a></li>
								<li><a href="#"><i class="icofont icofont-brand-linkedin"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-pinterest"></i></a></li>
								<li><a href="#"><i class="icofont icofont-social-google-plus"></i></a></li>
							</ul>
							<!-- <p>&copy;  -->
								<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
<!-- Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with  -->
<!-- <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a> -->
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --> 

<!-- </p> -->
						</div>
                    </div>
				</div>
			</div>




		</footer><!-- footer section end -->






		
		

<footer class="bg-body-tertiary text-center text-lg-start mobile_footer">
  
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.05);">

  <i class="icofont icofont-users-alt-3" style="color: black; font-size: 24px;"></i>

  <i class="icofont icofont-envelope" style="color: black; font-size: 24px;"></i>
  <i class="icofont-batch"></i>

  <span class="mdi mdi-message-processing"></span>


  </div>

</footer>





		<a href="#" class="scrollToTop">
			<i class="icofont icofont-arrow-up"></i>
		</a>


<!-- reg modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Registration Form</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
		</div>
		<div class="modal-body">      							
			<p class="form-message"></p>
			<input type="text" id="name" class="form_control" name="name" placeholder="Enter Your Name *">
			<input type="email" id="email" class="form_control" name="email" placeholder="Enter Your Email *">
			<input type="text" id="mobile_number"  class="form_control" name="mobile_number" placeholder="Mobile number *">
			<textarea placeholder="Address" class="form_control" name="address" id="address"></textarea>	
			<input type="hidden" id="record_value" name="record_value" value="0">		
			<input type="hidden" id="baseurl" value="<?php echo site_url(); ?>">
			<button type="submit" id="submitBtn" name="submit">Submit</button>
		</div>
    </div>
  </div>
</div>
<!--  -->





		<!-- jquery main JS -->
		<script src="assets/js/jquery.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="assets/js/bootstrap.min.js"></script>
		<!-- Slick nav JS -->
		<script src="assets/js/jquery.slicknav.min.js"></script>
		<!-- Slick JS -->
		<script src="assets/js/slick.min.js"></script>
		<!-- owl carousel JS -->
		<script src="assets/js/owl.carousel.min.js"></script>
		<!-- Popup JS -->
		<script src="assets/js/jquery.magnific-popup.min.js"></script>
		<!-- Counter JS -->
		<script src="assets/js/jquery.counterup.min.js"></script>
		<!-- Counterup waypoints JS -->
		<script src="assets/js/waypoints.min.js"></script>
	    <!-- YTPlayer JS -->
	    <script src="assets/js/jquery.mb.YTPlayer.min.js"></script>
		<!-- jQuery Easing JS -->
		<script src="assets/js/jquery.easing.1.3.js"></script>
		<!-- Gmap JS -->
		<script src="assets/js/gmap3.min.js"></script>
        <!-- Google map api -->
        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBnKyOpsNq-vWYtrwayN3BkF3b4k3O9A_A"></script>
		<!-- Custom map JS -->
		<script src="assets/js/custom-map.js"></script>
		<!-- WOW JS -->
		<script src="assets/js/wow-1.3.0.min.js"></script>
		<!-- Switcher JS -->
		<script src="assets/js/switcher.js"></script>
		<!-- main JS -->
		<script src="assets/js/main.js"></script>

		<script src="assets/js/operations.js"></script>

		<script src="assets/js/jquery.toast.js"></script>

	</body>
</html>

