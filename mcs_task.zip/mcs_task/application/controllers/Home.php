<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct(){		
		parent::__construct();	
		$this->load->database();
		$this->load->model('Home_model');
	}

	public function return_op($output=array()){
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		echo json_encode($output);exit;
	}
	
	public function index()
	{
		$this->load->view('home/index');
	}

	public function register() { 
  
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$mobile_number = $this->input->post('mobile_number');
		$address = $this->input->post('address');	
		$record_value = $this->input->post('record_value');

		$output_array = array('result'=>'', 'message'=>'');

		if (!preg_match("/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/", $email)) {
			$output_array['result'] = "Please enter a valid email address";
			$output_array['message'] = "Please enter a valid email address";
		} 

		else if (!preg_match("/^\d{10}$/", $mobile_number)) {
			$output_array['result'] = "Please enter a valid mobile number";
			$output_array['message'] = "Please enter a valid mobile number";
		} 

		if($output_array['result']!=''){
			$this->return_op($output_array);
		}
		$data = array(
			'name' => $name,
			'email' => $email,
			'mobile_number' => $mobile_number,
			'address' => $address,
			'id' => $record_value,
			'created_at' => date('Y-m-d h:m:s'),
		);
				
		$result = $this->Home_model->member_registration($data);	
						
		if ($result == "exist") {
			$output_array['result'] = $result;
			$output_array['message'] = "This person is already a registered member.";
		}
		else if($result == "inserted") {
			$output_array['result'] = $result;
			$output_array['message'] = "Registration completed successfully.";			
		}
		
		$this->return_op($output_array);
			
	}

	public function poll() { 
        $option = $this->input->post('option');
        $this->Home_model->save_poll($option);
    }

	public function get_results() {   
        //$data['results'] = $this->Home_model->get_results();
		$results = $this->Home_model->get_results();
		echo json_encode($results);
    }












}


